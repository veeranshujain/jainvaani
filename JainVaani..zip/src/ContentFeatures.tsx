import { useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { supabase } from "./lib/supabase";

const css = `
.jv-panel{background:#fffefa;border:1px solid #eee7dc;border-radius:14px;padding:20px;margin:18px 0}
.jv-panel h2{font-size:19px;color:#50351e;margin:0 0 12px}
.jv-form{display:grid;gap:9px;margin:12px 0}
.jv-form input,.jv-form textarea,.jv-form select{width:100%;padding:10px;border:1px solid #e5dac9;border-radius:8px;font:inherit}
.jv-form textarea{min-height:65px}
.jv-row{border:1px solid #eee5d8;border-radius:10px;padding:13px;margin:9px 0;background:white}
.jv-row h3{font-size:15px;margin:0 0 6px;color:#50351e}
.jv-btn{border:0;border-radius:8px;padding:9px 13px;background:#a65e20;color:white;font-weight:600;font-size:12px;cursor:pointer;margin:4px 6px 4px 0}
.jv-btn.alt{background:#eee6d9;color:#60462d}
.jv-btn:disabled{opacity:.5;cursor:not-allowed}
.jv-error{padding:10px;background:#fff0ed;color:#963b2d;border-radius:8px;font-size:12px;margin:10px 0}
.jv-muted{color:#8e8578;font-size:12px}
.jv-question{padding:12px;background:#fbf7ef;border-radius:9px;margin:10px 0}
.jv-question label{display:block;font-size:13px;margin:8px 0}
.jv-question input{width:auto;margin-right:8px}
.jv-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}
.jv-grid label{font-size:12px;color:#60462d}
.jv-grid input{display:block;width:100%;padding:10px;border:1px solid #e5dac9;border-radius:8px;margin-top:5px}
.jv-stat{background:#fbf7ef;border-radius:9px;padding:12px;margin:8px 0}
.jv-table{width:100%;border-collapse:collapse;font-size:12px;margin-top:12px}
.jv-table th,.jv-table td{border:1px solid #eee5d8;padding:8px;text-align:left}
.jv-table th{background:#fbf7ef;color:#50351e}
`;

function Panel({ children }: { children: ReactNode }) {
  return <section className="jv-panel"><style>{css}</style>{children}</section>;
}

const CERT_TYPES = [
  { value: "weekly_quiz", label: "Weekly Quiz Achievement" },
  { value: "monthly_morning", label: "Monthly Morning Swadhyay Attendance" },
  { value: "monthly_evening", label: "Monthly Evening Swadhyay Attendance" },
];

function certLabel(value: any) {
  return CERT_TYPES.find(x => x.value === value)?.label || String(value ?? "");
}

function escapeHtml(value: any) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]!);
}

function printCertificate(c: any) {
  const w = window.open("", "_blank");

  if (!w) {
    alert("Pop-ups allow karo, phir Print Certificate dabao.");
    return;
  }

  const name = escapeHtml(c.full_name || "JainVaani Member");
  const type = escapeHtml(certLabel(c.certificate_type));
  const number = escapeHtml(c.certificate_number);
  const start = escapeHtml(c.period_start);
  const end = escapeHtml(c.period_end);
  const issued = escapeHtml(c.issued_at ? new Date(c.issued_at).toLocaleDateString("en-IN") : "");

  w.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>JainVaani Certificate</title>
      <style>
        body{font-family:Georgia,serif;background:#faf7ef;padding:35px;color:#50351e}
        .box{border:9px double #b77a32;padding:55px 30px;text-align:center;background:white;min-height:480px}
        .brand{font-size:18px;letter-spacing:2px}
        .title{font-size:34px;margin:45px 0 30px}
        .name{font-size:30px;color:#9b5c20;margin:25px}
        .type{font-size:22px;font-weight:bold;margin:20px}
        .details{margin-top:35px;font-size:13px;line-height:2}
        @media print{body{padding:0;background:white}.box{min-height:90vh}}
      </style>
    </head>
    <body>
      <div class="box">
        <div class="brand">JAINVAANI · ज्ञान • संयम • साधना</div>
        <div class="title">Certificate of Achievement</div>
        <p>This certificate is proudly presented to</p>
        <div class="name">${name}</div>
        <p>For successfully completing the requirements for</p>
        <div class="type">${type}</div>
        <div class="details">
          Period: ${start} to ${end}<br/>
          Certificate No.: ${number}<br/>
          Issue Date: ${issued}
        </div>
        <h3 style="margin-top:35px">जय जिनेन्द्र</h3>
      </div>
    </body>
    </html>
  `);

  w.document.close();
  w.onload = () => w.print();
}

export function MemberPravachan() {
  const [rows, S] = useState<any[]>([]);
  const [err, E] = useState("");

  useEffect(() => {
    supabase.from("pravachan_playlists")
      .select("id,title,youtube_url,is_active")
      .eq("is_active", true)
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) E(error.message);
        else S(data || []);
      });
  }, []);

  return <Panel>
    <h2>▶ Previous Pravachan</h2>
    {err && <div className="jv-error">{err}</div>}
    {rows.length === 0 && !err && <p className="jv-muted">Abhi koi playlist publish nahi hui hai.</p>}
    {rows.map(x => <article className="jv-row" key={x.id}>
      <h3>{x.title}</h3>
      <a href={x.youtube_url} target="_blank" rel="noreferrer">YouTube playlist kholen ↗</a>
    </article>)}
  </Panel>;
}

export function MemberNotices() {
  const [rows, S] = useState<any[]>([]);
  const [err, E] = useState("");

  useEffect(() => {
    supabase.from("notices")
      .select("id,title,content,is_published,created_at")
      .eq("is_published", true)
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) E(error.message);
        else S(data || []);
      });
  }, []);

  return <Panel>
    <h2>♧ सूचनाएँ / Notices</h2>
    {err && <div className="jv-error">{err}</div>}
    {rows.length === 0 && !err && <p className="jv-muted">Abhi koi nayi soochna nahi hai.</p>}
    {rows.map(x => <article className="jv-row" key={x.id}>
      <h3>{x.title}</h3>
      <p>{x.content}</p>
    </article>)}
  </Panel>;
}

export function MemberQuizzes() {
  const [rows, S] = useState<any[]>([]);
  const [quiz, Q] = useState<any>(null);
  const [questions, QS] = useState<any[]>([]);
  const [answers, A] = useState<Record<string, string>>({});
  const [err, E] = useState("");
  const [busy, B] = useState(false);
  const [result, R] = useState<any>(null);

  const [certificates, CS] = useState<any[]>([]);
  const [verifyNumber, VN] = useState("");
  const [verifyResult, VR] = useState<any>(null);
  const [verifyError, VE] = useState("");

  async function load() {
    const { data, error } = await supabase.from("quizzes")
      .select("id,title,description,is_published")
      .eq("is_published", true)
      .order("created_at", { ascending: false });

    if (error) E(error.message);
    else S(data || []);
  }

  async function loadCertificates() {
    const { data, error } = await supabase.rpc("get_my_jainvaani_certificates");
    if (error) E(error.message);
    else CS(data || []);
  }

  useEffect(() => {
    void load();
    void loadCertificates();
  }, []);

  async function start(q: any) {
    B(true);
    E("");
    R(null);
    A({});

    const { data, error } = await supabase.from("quiz_questions")
      .select("id,question,points,position")
      .eq("quiz_id", q.id)
      .order("position");

    if (error) {
      E(error.message);
      B(false);
      return;
    }

    const list: any[] = [];

    for (const x of data || []) {
      const r = await supabase.from("quiz_options")
        .select("id,option_text,position")
        .eq("question_id", x.id)
        .order("position");

      if (r.error) {
        E(r.error.message);
        B(false);
        return;
      }

      list.push({ ...x, options: r.data || [] });
    }

    QS(list);
    Q(q);
    B(false);
  }

  async function submit() {
    if (!quiz) return;

    if (questions.some(q => !answers[q.id])) {
      E("Har question ka answer select karo.");
      return;
    }

    B(true);

    const { data, error } = await supabase.rpc("submit_jainvaani_quiz", {
      p_quiz_id: quiz.id,
      p_answers: questions.map(q => ({
        question_id: q.id,
        selected_option_id: answers[q.id],
      })),
    });

    B(false);

    if (error) {
      E(error.message);
      return;
    }

    const r = Array.isArray(data) ? data[0] : data;
    R(r);
    Q(null);
  }

  async function verifyCertificate(e: FormEvent) {
    e.preventDefault();
    VE("");
    VR(null);

    if (!verifyNumber.trim()) {
      VE("Certificate number enter karo.");
      return;
    }

    const { data, error } = await supabase.rpc("verify_jainvaani_certificate", {
      p_certificate_number: verifyNumber.trim(),
    });

    if (error) {
      VE(error.message);
      return;
    }

    const r = Array.isArray(data) ? data[0] : data;

    if (!r || !r.is_valid) {
      VE("Certificate number nahi mila. Number dobara check karo.");
      return;
    }

    VR(r);
  }

  return <Panel>
    <h2>✎ Published Quizzes</h2>

    {err && <div className="jv-error">{err}</div>}

    {result && <div className="jv-row">
      <h3>Quiz Result</h3>
      Score: {result.score}/{result.total_points}
      <p className="jv-muted">Certificates admin ke eligibility process ke baad issue honge.</p>
    </div>}

    {quiz ? <>
      <h3>{quiz.title}</h3>
      {questions.map((q, i) => <div className="jv-question" key={q.id}>
        <b>{i + 1}. {q.question} ({q.points} points)</b>
        {q.options.map((o: any) => <label key={o.id}>
          <input
            type="radio"
            name={q.id}
            checked={answers[q.id] === o.id}
            onChange={() => A(a => ({ ...a, [q.id]: o.id }))}
          />
          {o.option_text}
        </label>)}
      </div>)}
      <button className="jv-btn" disabled={busy} onClick={() => void submit()}>Submit quiz</button>
      <button className="jv-btn alt" onClick={() => Q(null)}>Cancel</button>
    </> : rows.map(q => <article className="jv-row" key={q.id}>
      <h3>{q.title}</h3>
      <p>{q.description}</p>
      <button className="jv-btn" onClick={() => void start(q)}>Start quiz</button>
    </article>)}

    <hr />
    {false && <h2>🏅 My Certificates</h2>}

    {false ? null : certificates.length === 0
      ? <p className="jv-muted">Abhi aapko koi certificate issue nahi hua hai.</p>
      : certificates.map(c => <article className="jv-row" key={c.certificate_id}>
        <h3>{certLabel(c.certificate_type)}</h3>
        <p>Period: {c.period_start} to {c.period_end}</p>
        <p>Certificate No.: <b>{c.certificate_number}</b></p>
        <p className="jv-muted">Issued: {new Date(c.issued_at).toLocaleDateString("en-IN")}</p>
        <button className="jv-btn" onClick={() => printCertificate(c)}>Print / Save PDF</button>
      </article>)}

    <hr />
    <h2>🔎 Verify Certificate</h2>
    <form className="jv-form" onSubmit={verifyCertificate}>
      <input
        value={verifyNumber}
        onChange={e => VN(e.target.value)}
        placeholder="Enter certificate number"
      />
      <button className="jv-btn">Verify</button>
    </form>

    {verifyError && <div className="jv-error">{verifyError}</div>}

    {verifyResult && <article className="jv-row">
      <h3>✓ Certificate Valid</h3>
      <p>Name: {verifyResult.full_name}</p>
      <p>Certificate: {certLabel(verifyResult.certificate_type)}</p>
      <p>Number: {verifyResult.certificate_number}</p>
      <p>Period: {verifyResult.period_start} to {verifyResult.period_end}</p>
    </article>}
  </Panel>;
}

export function AdminContent() {
  const [quizzes, Q] = useState<any[]>([]);
  const [notices, N] = useState<any[]>([]);
  const [lists, L] = useState<any[]>([]);
  const [members, M] = useState<any[]>([]);

  const [title, T] = useState("");
  const [desc, D] = useState("");
  const [qid, ID] = useState("");
  const [question, QT] = useState("");
  const [points, P] = useState("1");
  const [opts, O] = useState(["", "", "", ""]);
  const [correct, C] = useState(0);

  const [nt, NT] = useState("");
  const [nb, NB] = useState("");
  const [pt, PT] = useState("");
  const [pu, PU] = useState("");

  const [err, E] = useState("");
  const [msg, G] = useState("");

  const [certType, CT] = useState("weekly_quiz");
  const [minPercent, MP] = useState("75");
  const [minQuizzes, MQ] = useState("3");
  const [certEnabled, CE] = useState(true);
  const [periodStart, PS] = useState("");
  const [periodEnd, PE] = useState("");
  const [preview, PV] = useState<any[]>([]);
  const [issued, IS] = useState<any[]>([]);
  const [certBusy, CB] = useState(false);

  async function refresh() {
    const [a, b, c, d] = await Promise.all([
      supabase.from("quizzes").select("*").order("created_at", { ascending: false }),
      supabase.from("notices").select("*").order("created_at", { ascending: false }),
      supabase.from("pravachan_playlists").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("id,full_name,role").order("full_name"),
    ]);

    const errors = [a.error, b.error, c.error, d.error].filter(Boolean);
    if (errors.length) E(errors.map(x => x!.message).join(" | "));

    Q(a.data || []);
    N(b.data || []);
    L(c.data || []);
    M(d.data || []);
  }

  useEffect(() => {
    void refresh();
    const today = new Date().toISOString().slice(0, 10);
    PS(today);
    PE(today);
  }, []);

  async function createQuiz(e: FormEvent) {
    e.preventDefault();

    const r = await supabase.from("quizzes")
      .insert({
        title: title.trim(),
        description: desc.trim() || null,
        is_published: false,
      })
      .select("id")
      .single();

    if (r.error) {
      E(r.error.message);
      return;
    }

    ID(r.data.id);
    T("");
    D("");
    G("Draft quiz bana. Ab question add karo.");
    void refresh();
  }

  async function addQuestion(e: FormEvent) {
    e.preventDefault();

    if (opts.some(x => !x.trim())) {
      E("Chaaro options bharo.");
      return;
    }

    const last = await supabase.from("quiz_questions")
      .select("position")
      .eq("quiz_id", qid)
      .order("position", { ascending: false })
      .limit(1);

    const nextPosition = ((last.data && last.data[0]?.position) || 0) + 1;

    const r = await supabase.from("quiz_questions")
      .insert({
        quiz_id: qid,
        question: question.trim(),
        points: Number(points) || 1,
        position: nextPosition,
      })
      .select("id")
      .single();

    if (r.error) {
      E(r.error.message);
      return;
    }

    const o = await supabase.from("quiz_options")
      .insert(opts.map((x, i) => ({
        question_id: r.data.id,
        option_text: x.trim(),
        position: i + 1,
      })))
      .select("id,position");

    if (o.error) {
      E(o.error.message);
      return;
    }

    const key = o.data?.find(x => x.position === correct + 1);

    const k = await supabase.from("quiz_answer_keys").insert({
      question_id: r.data.id,
      correct_option_id: key?.id,
    });

    if (k.error) {
      E(k.error.message);
      return;
    }

    QT("");
    O(["", "", "", ""]);
    G("Question save ho gaya.");
  }

  async function publish(id: string, v: boolean) {
    const r = await supabase.from("quizzes").update({ is_published: v }).eq("id", id);
    if (r.error) E(r.error.message);
    else void refresh();
  }

  async function addNotice(e: FormEvent) {
    e.preventDefault();

    const r = await supabase.from("notices").insert({
      title: nt.trim(),
      content: nb.trim(),
      is_published: true,
    });

    if (r.error) E(r.error.message);
    else {
      NT("");
      NB("");
      G("Notice publish ho gaya.");
      void refresh();
    }
  }

  async function addPlaylist(e: FormEvent) {
    e.preventDefault();

    try {
      new URL(pu);
    } catch {
      E("Valid URL daalo.");
      return;
    }

    const r = await supabase.from("pravachan_playlists").insert({
      title: pt.trim(),
      youtube_url: pu.trim(),
      is_active: true,
    });

    if (r.error) E(r.error.message);
    else {
      PT("");
      PU("");
      G("Playlist add ho gayi.");
      void refresh();
    }
  }

  async function toggle(table: string, row: any, key: string) {
    const r = await supabase.from(table)
      .update({ [key]: !row[key] })
      .eq("id", row.id);

    if (r.error) E(r.error.message);
    else void refresh();
  }

  // Certificate settings save with visible success/error feedback
  async function saveCertificateSettings() {
    E("");
    G("Saving certificate settings...");
    CB(true);

    try {
      const { error } = await supabase.rpc("admin_save_certificate_settings", {
        p_certificate_type: certType.trim(),
        p_minimum_percentage: Number(minPercent),
        p_minimum_quizzes: Number(minQuizzes),
        p_is_enabled: certEnabled,
      });

      if (error) {
        E("Save failed: " + error.message);
        G("");
        return;
      }

      G("✅ Certificate settings successfully save ho gayi.");
    } catch (error: any) {
      E("Unexpected error: " + (error?.message || String(error)));
      G("");
    } finally {
      CB(false);
    }
  }

  async function previewEligibility() {
    E("");
    G("");
    PV([]);
    IS([]);

    if (!periodStart || !periodEnd || periodEnd < periodStart) {
      E("Valid start aur end date select karo.");
      return;
    }

    CB(true);

    try {
      const { data, error } = await supabase.rpc("admin_preview_certificate_eligibility", {
        p_certificate_type: certType.trim(),
        p_period_start: periodStart,
        p_period_end: periodEnd,
      });

      if (error) {
        E(error.message);
        return;
      }

      PV(data || []);
      G("Eligibility preview ready hai.");
    } catch (error: any) {
      E(error?.message || String(error));
    } finally {
      CB(false);
    }
  }

  async function issueCertificates() {
    if (!window.confirm("Eligible members ko certificates issue karne hain?")) return;

    E("");
    G("");
    CB(true);

    try {
      const { data, error } = await supabase.rpc("admin_issue_certificates", {
        p_certificate_type: certType.trim(),
        p_period_start: periodStart,
        p_period_end: periodEnd,
      });

      if (error) {
        E(error.message);
        return;
      }

      IS(data || []);
      G(`${(data || []).length} certificate records mil gaye. Pehle se issued certificates dobara create nahi honge.`);
    } catch (error: any) {
      E(error?.message || String(error));
    } finally {
      CB(false);
    }
  }

  const eligibleCount = preview.filter(x => x.eligible).length;

  return <Panel>
    <h2>⚙ JainVaani Control Center</h2>
    <p>Quiz, notices, playlists, members aur certificates manage karein.</p>

    {err && <div className="jv-error">{err}</div>}
    {msg && <p>{msg}</p>}

    <h3>1. Quiz Management</h3>

    <form className="jv-form" onSubmit={createQuiz}>
      <input value={title} onChange={e => T(e.target.value)} placeholder="Quiz title" required />
      <textarea value={desc} onChange={e => D(e.target.value)} placeholder="Description" />
      <button className="jv-btn">Create draft quiz</button>
    </form>

    <select value={qid} onChange={e => ID(e.target.value)}>
      <option value="">Question ke liye quiz select karo</option>
      {quizzes.map(q => <option key={q.id} value={q.id}>{q.title}</option>)}
    </select>

    <form className="jv-form" onSubmit={addQuestion}>
      <input value={question} onChange={e => QT(e.target.value)} placeholder="Question" required />
      <input type="number" min="1" value={points} onChange={e => P(e.target.value)} />

      {opts.map((v, i) => <label key={i}>
        <input
          value={v}
          onChange={e => O(old => old.map((x, j) => j === i ? e.target.value : x))}
          placeholder={`Option ${i + 1}`}
          required
        />
        <input
          type="radio"
          name="jv-correct"
          checked={correct === i}
          onChange={() => C(i)}
        /> Correct
      </label>)}

      <button className="jv-btn" disabled={!qid}>Add question</button>
    </form>

    {quizzes.map(q => <article className="jv-row" key={q.id}>
      <h3>{q.title}</h3>
      <p>{q.is_published ? "Published" : "Draft"}</p>
      <button className="jv-btn" onClick={() => ID(q.id)}>Add questions</button>
      <button className="jv-btn alt" onClick={() => void publish(q.id, !q.is_published)}>
        {q.is_published ? "Unpublish" : "Publish"}
      </button>
    </article>)}

    <hr />
    <h3>2. Notices</h3>

    <form className="jv-form" onSubmit={addNotice}>
      <input value={nt} onChange={e => NT(e.target.value)} placeholder="Notice title" required />
      <textarea value={nb} onChange={e => NB(e.target.value)} placeholder="Notice content" required />
      <button className="jv-btn">Publish notice</button>
    </form>

    {notices.map(n => <article className="jv-row" key={n.id}>
      <h3>{n.title}</h3>
      <p>{n.content}</p>
      <button className="jv-btn alt" onClick={() => void toggle("notices", n, "is_published")}>
        {n.is_published ? "Unpublish" : "Publish"}
      </button>
    </article>)}

    <hr />
    <h3>3. Previous Pravachan</h3>

    <form className="jv-form" onSubmit={addPlaylist}>
      <input value={pt} onChange={e => PT(e.target.value)} placeholder="Playlist title" required />
      <input type="url" value={pu} onChange={e => PU(e.target.value)} placeholder="YouTube playlist URL" required />
      <button className="jv-btn">Add playlist</button>
    </form>

    {lists.map(p => <article className="jv-row" key={p.id}>
      <h3>{p.title}</h3>
      <a href={p.youtube_url} target="_blank" rel="noreferrer">Open playlist ↗</a>
      <button className="jv-btn alt" onClick={() => void toggle("pravachan_playlists", p, "is_active")}>
        {p.is_active ? "Archive" : "Restore"}
      </button>
    </article>)}

    <hr />
    <h3>4. Members ({members.length})</h3>

    {members.map(m => <article className="jv-row" key={m.id}>
      <b>{m.full_name || "Unnamed member"}</b>
      <p>{m.role}</p>
    </article>)}

    <hr />
    <h3>5. 🏅 Certificate Management</h3>
    <p className="jv-muted">Certificate type, attendance percentage aur completed quizzes ke basis par eligibility decide hogi.</p>

    <div className="jv-form">
      <label>Certificate type
        <select value={certType} onChange={e => CT(e.target.value)}>
          {CERT_TYPES.map(x => <option key={x.value} value={x.value}>{x.label}</option>)}
        </select>
      </label>

      <div className="jv-grid">
        <label>Minimum attendance %
          <input type="number" min="0" max="100" value={minPercent} onChange={e => MP(e.target.value)} required />
        </label>

        <label>Minimum completed quizzes
          <input type="number" min="0" value={minQuizzes} onChange={e => MQ(e.target.value)} required />
        </label>
      </div>

      <label>
        <input type="checkbox" checked={certEnabled} onChange={e => CE(e.target.checked)} />
        Certificate enabled
      </label>

      <button
        type="button"
        className="jv-btn"
        disabled={certBusy}
        onClick={() => void saveCertificateSettings()}
      >
        {certBusy ? "Saving..." : "Save certificate settings"}
      </button>

      {err && <div className="jv-error" role="alert">{err}</div>}
      {msg && <p role="status"><b>{msg}</b></p>}
    </div>

    <h3>Eligibility Period</h3>

    <div className="jv-grid">
      <label>Period start
        <input type="date" value={periodStart} onChange={e => PS(e.target.value)} />
      </label>
      <label>Period end
        <input type="date" value={periodEnd} onChange={e => PE(e.target.value)} />
      </label>
    </div>

    <button
      type="button"
      className="jv-btn"
      disabled={certBusy}
      onClick={() => void previewEligibility()}
    >
      {certBusy ? "Please wait..." : "Preview eligibility"}
    </button>

    {err && <div className="jv-error" role="alert">{err}</div>}
    {msg && <p role="status"><b>{msg}</b></p>}

    {preview.length > 0 && <>
      <div className="jv-stat">
        Total members: <b>{preview.length}</b> |
        Eligible: <b>{eligibleCount}</b> |
        Not eligible: <b>{preview.length - eligibleCount}</b>
      </div>

      <div style={{ overflowX: "auto" }}>
        <table className="jv-table">
          <thead>
            <tr>
              <th>Member</th>
              <th>Attendance</th>
              <th>Quizzes</th>
              <th>Eligibility</th>
            </tr>
          </thead>
          <tbody>
            {preview.map(x => <tr key={x.member_id}>
              <td>{x.full_name}</td>
              <td>{x.attendance_percentage}%</td>
              <td>{x.quizzes_completed}</td>
              <td>{x.eligible ? "Eligible" : "Not eligible"}</td>
            </tr>)}
          </tbody>
        </table>
      </div>

      <button
        className="jv-btn"
        disabled={certBusy || eligibleCount === 0 || !certEnabled}
        onClick={() => void issueCertificates()}
      >
        Issue certificates ({eligibleCount})
      </button>
    </>}

    {issued.length > 0 && <>
      <h3>Issued Certificates</h3>
      {issued.map(c => <article className="jv-row" key={c.certificate_id}>
        <b>{c.full_name}</b>
        <p>Certificate No.: {c.certificate_number}</p>
        <p>Attendance: {c.attendance_percentage}% | Quizzes: {c.quizzes_completed}</p>
      </article>)}
    </>}
  </Panel>;
}

// ===================== DASHBOARDS, QUIZ HISTORY, LEADERBOARD =====================
function monthStartStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

function errText(e: any) {
  return e?.message || e?.details || e?.hint || e?.code || "Unknown error. Permission ya network check karo.";
}

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return <div className="jv-stat" style={{ textAlign: "center" }}>
    <div style={{ fontSize: 26, fontWeight: 700, color: "#a65e20" }}>{value}</div>
    <div className="jv-muted">{label}</div>
  </div>;
}

export function MemberDashboard() {
  const [d, setD] = useState<any>(null);
  const [err, E] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const { data: u } = await supabase.auth.getUser();
        const uid = u.user?.id;
        if (!uid) return;

        const held = await supabase.from("attendance_sessions").select("id")
          .eq("status", "held").gte("session_date", monthStartStr());
        if (held.error) throw held.error;
        const ids = (held.data || []).map((x: any) => x.id);

        let present = 0;
        if (ids.length) {
          const pr = await supabase.from("attendance_records").select("id")
            .eq("user_id", uid).eq("status", "present").in("attendance_session_id", ids);
          if (pr.error) throw pr.error;
          present = (pr.data || []).length;
        }

        const hi = await supabase.rpc("get_my_jainvaani_quiz_history", { p_limit: 100 });
        if (hi.error) throw hi.error;
        const rows: any[] = hi.data || [];
        const sc = rows.reduce((a, x) => a + Number(x.score || 0), 0);
        const tp = rows.reduce((a, x) => a + Number(x.total_points || 0), 0);

        const ce = await supabase.rpc("get_my_jainvaani_certificates");
        if (ce.error) throw ce.error;

        setD({
          held: ids.length,
          present,
          pct: ids.length ? Math.round((present * 100) / ids.length) : 0,
          quizzes: rows.length,
          avg: tp ? Math.round((sc * 100) / tp) : 0,
          certs: (ce.data || []).length,
        });
      } catch (e: any) {
        E(errText(e));
      }
    })();
  }, []);

  return <Panel>
    <h2>📊 Meri Activity (is mahine)</h2>
    {err && <div className="jv-error">{err}</div>}
    {!d && !err && <p className="jv-muted">Loading...</p>}
    {d && <div className="jv-grid">
      <Stat label="Attendance" value={`${d.pct}%`} />
      <Stat label="Present / Total sessions" value={`${d.present}/${d.held}`} />
      <Stat label="Quizzes diye" value={d.quizzes} />
      <Stat label="Average score" value={`${d.avg}%`} />
      <Stat label="Certificates" value={d.certs} />
    </div>}
  </Panel>;
}

export function AdminDashboard() {
  const [d, setD] = useState<any>(null);
  const [err, E] = useState("");

  useEffect(() => {
    supabase.rpc("get_admin_dashboard_stats").then(({ data, error }) => {
      if (error) E(errText(error));
      else setD(Array.isArray(data) ? data[0] : data);
    });
  }, []);

  return <Panel>
    <h2>📈 Admin Dashboard</h2>
    {err && <div className="jv-error">{err}</div>}
    {!d && !err && <p className="jv-muted">Loading...</p>}
    {d && <div className="jv-grid">
      <Stat label="Total members" value={d.members} />
      <Stat label="Quizzes" value={d.quizzes} />
      <Stat label="Notices" value={d.notices} />
      <Stat label="Sessions (is mahine)" value={d.sessions_this_month} />
      <Stat label="Quiz attempts" value={d.quiz_attempts} />
      <Stat label="Certificates issued" value={d.certificates} />
    </div>}
  </Panel>;
}

export function QuizHistory() {
  const [rows, S] = useState<any[]>([]);
  const [err, E] = useState("");
  const [loading, L] = useState(true);

  useEffect(() => {
    supabase.rpc("get_my_jainvaani_quiz_history", { p_limit: 30 }).then(({ data, error }) => {
      if (error) E(errText(error));
      else S(data || []);
      L(false);
    });
  }, []);

  return <Panel>
    <h2>🕘 Meri Quiz History</h2>
    {err && <div className="jv-error">{err}</div>}
    {loading && <p className="jv-muted">Loading...</p>}
    {!loading && !err && rows.length === 0 && <p className="jv-muted">Abhi tak koi quiz attempt nahi hai.</p>}
    {rows.map(x => <article className="jv-row" key={x.attempt_id}>
      <h3>{x.quiz_title}</h3>
      <p>Score: <b>{x.score}/{x.total_points}</b></p>
      <p className="jv-muted">{x.completed_at ? new Date(x.completed_at).toLocaleString("en-IN") : ""}</p>
    </article>)}
  </Panel>;
}

export function Leaderboard() {
  const [rows, S] = useState<any[]>([]);
  const [err, E] = useState("");
  const [loading, L] = useState(true);

  useEffect(() => {
    supabase.rpc("get_jainvaani_leaderboard", { p_limit: 20 }).then(({ data, error }) => {
      if (error) E(errText(error));
      else S(data || []);
      L(false);
    });
  }, []);

  return <Panel>
    <h2>🏆 Leaderboard</h2>
    {err && <div className="jv-error">{err}</div>}
    {loading && <p className="jv-muted">Loading...</p>}
    {!loading && !err && rows.length === 0 && <p className="jv-muted">Abhi leaderboard khaali hai.</p>}
    {rows.length > 0 && <table className="jv-table">
      <thead><tr><th>#</th><th>Naam</th><th>Average</th><th>Quizzes</th></tr></thead>
      <tbody>
        {rows.map((x, i) => <tr key={i}>
          <td>{x.rank}</td><td>{x.display_name}</td><td>{x.percentage}%</td><td>{x.quizzes_taken}</td>
        </tr>)}
      </tbody>
    </table>}
  </Panel>;
}


// ===================== NOTIFICATIONS, PROFILE, MEMBER SEARCH =====================
export function NotificationsBar() {
  const [items, S] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      let seen: string[] = [];
      try { seen = JSON.parse(localStorage.getItem("jv_seen_notifs") || "[]"); } catch { seen = []; }
      const since = new Date(Date.now() - 7 * 86400000).toISOString();
      const [n, q] = await Promise.all([
        supabase.from("notices").select("id,title,created_at").eq("is_published", true)
          .gte("created_at", since).order("created_at", { ascending: false }).limit(5),
        supabase.from("quizzes").select("id,title,created_at").eq("is_published", true)
          .gte("created_at", since).order("created_at", { ascending: false }).limit(5),
      ]);
      const list = [
        ...(n.data || []).map((x: any) => ({ key: "n" + x.id, icon: "📢", text: "Nayi soochna: " + x.title, at: x.created_at })),
        ...(q.data || []).map((x: any) => ({ key: "q" + x.id, icon: "✎", text: "Naya quiz: " + x.title, at: x.created_at })),
      ].filter(x => !seen.includes(x.key)).sort((a, b) => String(b.at).localeCompare(String(a.at)));
      S(list);
    })();
  }, []);

  function dismiss(keys: string[]) {
    try {
      const old: string[] = JSON.parse(localStorage.getItem("jv_seen_notifs") || "[]");
      localStorage.setItem("jv_seen_notifs", JSON.stringify([...old, ...keys].slice(-200)));
    } catch { /* storage unavailable */ }
    S(list => list.filter(x => !keys.includes(x.key)));
  }

  if (items.length === 0) return null;

  return <Panel>
    <h2>🔔 Nayi Notifications ({items.length})</h2>
    {items.map(x => <article className="jv-row" key={x.key}>
      <p>{x.icon} {x.text}</p>
      <button className="jv-btn alt" onClick={() => dismiss([x.key])}>Dismiss</button>
    </article>)}
    <button className="jv-btn" onClick={() => dismiss(items.map(x => x.key))}>Sab dismiss karo</button>
  </Panel>;
}

export function MyProfile() {
  const [name, N] = useState("");
  const [uid, U] = useState("");
  const [msg, G] = useState("");
  const [err, E] = useState("");
  const [busy, B] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      const id = u.user?.id;
      if (!id) return;
      U(id);
      const r = await supabase.from("profiles").select("full_name").eq("id", id).maybeSingle();
      if (r.error) E(errText(r.error));
      else N(r.data?.full_name || "");
    })();
  }, []);

  async function save(e: FormEvent) {
    e.preventDefault();
    E("");
    G("");
    if (!name.trim()) { E("Naam khaali nahi ho sakta."); return; }
    B(true);
    const r = await supabase.from("profiles").update({ full_name: name.trim() }).eq("id", uid).select("id");
    B(false);
    if (r.error) E(errText(r.error));
    else if (!r.data || r.data.length === 0) E("Naam save nahi hua (permission nahi mili).");
    else G("✅ Profile update ho gaya.");
  }

  return <Panel>
    <h2>👤 Mera Profile</h2>
    <form className="jv-form" onSubmit={save}>
      <label>Poora naam
        <input value={name} onChange={e => N(e.target.value)} placeholder="Aapka naam" />
      </label>
      <button className="jv-btn" disabled={busy || !uid}>{busy ? "Saving..." : "Save profile"}</button>
    </form>
    {err && <div className="jv-error">{err}</div>}
    {msg && <p><b>{msg}</b></p>}
  </Panel>;
}

export function AdminMembers() {
  const [rows, S] = useState<any[]>([]);
  const [q, Q] = useState("");
  const [role, R] = useState("all");
  const [err, E] = useState("");
  const [loading, L] = useState(true);

  useEffect(() => {
    supabase.from("profiles").select("id,full_name,role").order("full_name").then(({ data, error }) => {
      if (error) E(errText(error));
      else S(data || []);
      L(false);
    });
  }, []);

  const roles = Array.from(new Set(rows.map(x => x.role).filter(Boolean)));
  const shown = rows.filter(x =>
    (role === "all" || x.role === role) &&
    (x.full_name || "").toLowerCase().includes(q.trim().toLowerCase())
  );

  return <Panel>
    <h2>👥 Member Search ({shown.length}/{rows.length})</h2>
    {err && <div className="jv-error">{err}</div>}
    {loading && <p className="jv-muted">Loading...</p>}
    <div className="jv-form">
      <input value={q} onChange={e => Q(e.target.value)} placeholder="Naam se search karo" />
      <select value={role} onChange={e => R(e.target.value)}>
        <option value="all">Sab roles</option>
        {roles.map(r => <option key={r} value={r}>{r}</option>)}
      </select>
    </div>
    {!loading && shown.length === 0 && <p className="jv-muted">Koi member nahi mila.</p>}
    {shown.map(m => <article className="jv-row" key={m.id}>
      <b>{m.full_name || "Unnamed member"}</b>
      <p className="jv-muted">{m.role}</p>
    </article>)}
  </Panel>;
}


// ===================== EDIT/DELETE CONTENT, CERTIFICATE HISTORY =====================
export function AdminContentEditor() {
  const [notices, N] = useState<any[]>([]);
  const [lists, L] = useState<any[]>([]);
  const [edit, ED] = useState<{ table: string; id: string; a: string; b: string } | null>(null);
  const [err, E] = useState("");
  const [msg, G] = useState("");

  async function load() {
    const [n, p] = await Promise.all([
      supabase.from("notices").select("id,title,content").order("created_at", { ascending: false }),
      supabase.from("pravachan_playlists").select("id,title,youtube_url").order("created_at", { ascending: false }),
    ]);
    if (n.error || p.error) E(errText(n.error || p.error));
    N(n.data || []);
    L(p.data || []);
  }
  useEffect(() => { void load(); }, []);

  async function save() {
    if (!edit) return;
    E(""); G("");
    if (!edit.a.trim() || !edit.b.trim()) { E("Dono fields bharo."); return; }
    if (edit.table === "pravachan_playlists") {
      try { new URL(edit.b); } catch { E("Valid URL daalo."); return; }
    }
    const patch = edit.table === "notices"
      ? { title: edit.a.trim(), content: edit.b.trim() }
      : { title: edit.a.trim(), youtube_url: edit.b.trim() };
    const r = await supabase.from(edit.table).update(patch).eq("id", edit.id).select("id");
    if (r.error) E(errText(r.error));
    else if (!r.data || r.data.length === 0) E("Save nahi hua (permission nahi mili).");
    else { G("✅ Save ho gaya."); ED(null); void load(); }
  }

  async function remove(table: string, id: string, label: string) {
    if (!window.confirm(`"${label}" permanently delete karna hai? Ye wapas nahi aayega. (Chhupane ke liye Unpublish/Archive use karo.)`)) return;
    E(""); G("");
    const r = await supabase.from(table).delete().eq("id", id).select("id");
    if (r.error) E(errText(r.error));
    else if (!r.data || r.data.length === 0) E("Delete nahi hua (permission nahi mili).");
    else { G("🗑 Delete ho gaya."); void load(); }
  }

  const editor = (table: string, id: string) => edit && edit.table === table && edit.id === id;

  return <Panel>
    <h2>✏️ Notices / Pravachan Edit & Delete</h2>
    {err && <div className="jv-error">{err}</div>}
    {msg && <p><b>{msg}</b></p>}

    <h3>Notices</h3>
    {notices.map(n => <article className="jv-row" key={n.id}>
      {editor("notices", n.id) ? <div className="jv-form">
        <input value={edit!.a} onChange={e => ED({ ...edit!, a: e.target.value })} />
        <textarea value={edit!.b} onChange={e => ED({ ...edit!, b: e.target.value })} />
        <div>
          <button className="jv-btn" onClick={() => void save()}>Save</button>
          <button className="jv-btn alt" onClick={() => ED(null)}>Cancel</button>
        </div>
      </div> : <>
        <h3>{n.title}</h3>
        <p>{n.content}</p>
        <button className="jv-btn" onClick={() => ED({ table: "notices", id: n.id, a: n.title, b: n.content })}>Edit</button>
        <button className="jv-btn alt" onClick={() => void remove("notices", n.id, n.title)}>Delete</button>
      </>}
    </article>)}
    {notices.length === 0 && <p className="jv-muted">Koi notice nahi hai.</p>}

    <h3>Pravachan Playlists</h3>
    {lists.map(p => <article className="jv-row" key={p.id}>
      {editor("pravachan_playlists", p.id) ? <div className="jv-form">
        <input value={edit!.a} onChange={e => ED({ ...edit!, a: e.target.value })} />
        <input type="url" value={edit!.b} onChange={e => ED({ ...edit!, b: e.target.value })} />
        <div>
          <button className="jv-btn" onClick={() => void save()}>Save</button>
          <button className="jv-btn alt" onClick={() => ED(null)}>Cancel</button>
        </div>
      </div> : <>
        <h3>{p.title}</h3>
        <p className="jv-muted">{p.youtube_url}</p>
        <button className="jv-btn" onClick={() => ED({ table: "pravachan_playlists", id: p.id, a: p.title, b: p.youtube_url })}>Edit</button>
        <button className="jv-btn alt" onClick={() => void remove("pravachan_playlists", p.id, p.title)}>Delete</button>
      </>}
    </article>)}
    {lists.length === 0 && <p className="jv-muted">Koi playlist nahi hai.</p>}
  </Panel>;
}

export function AdminCertificateHistory() {
  const [rows, S] = useState<any[]>([]);
  const [q, Q] = useState("");
  const [type, T] = useState("all");
  const [err, E] = useState("");
  const [loading, L] = useState(true);

  useEffect(() => {
    (async () => {
      const [c, p] = await Promise.all([
        supabase.from("jainvaani_certificates")
          .select("id,user_id,certificate_type,period_start,period_end,certificate_number,issued_at")
          .order("issued_at", { ascending: false }).limit(500),
        supabase.from("profiles").select("id,full_name"),
      ]);
      if (c.error) E(errText(c.error));
      const names: Record<string, string> = {};
      (p.data || []).forEach((x: any) => { names[x.id] = x.full_name || "Unnamed member"; });
      S((c.data || []).map((x: any) => ({ ...x, name: names[x.user_id] || "Unknown" })));
      L(false);
    })();
  }, []);

  const needle = q.trim().toLowerCase();
  const shown = rows.filter(x =>
    (type === "all" || x.certificate_type === type) &&
    (!needle || x.name.toLowerCase().includes(needle) || String(x.certificate_number).toLowerCase().includes(needle))
  );

  return <Panel>
    <h2>🗂 Certificate History ({shown.length}/{rows.length})</h2>
    {err && <div className="jv-error">{err}</div>}
    {loading && <p className="jv-muted">Loading...</p>}
    <div className="jv-form">
      <input value={q} onChange={e => Q(e.target.value)} placeholder="Naam ya certificate number se search" />
      <select value={type} onChange={e => T(e.target.value)}>
        <option value="all">Sab types</option>
        {CERT_TYPES.map(x => <option key={x.value} value={x.value}>{x.label}</option>)}
      </select>
    </div>
    {!loading && shown.length === 0 && <p className="jv-muted">Koi certificate nahi mila.</p>}
    <div style={{ overflowX: "auto" }}>
      {shown.length > 0 && <table className="jv-table">
        <thead><tr><th>Member</th><th>Type</th><th>Period</th><th>Number</th><th>Issued</th></tr></thead>
        <tbody>
          {shown.map(x => <tr key={x.id}>
            <td>{x.name}</td>
            <td>{certLabel(x.certificate_type)}</td>
            <td>{x.period_start} → {x.period_end}</td>
            <td>{x.certificate_number}</td>
            <td>{new Date(x.issued_at).toLocaleDateString("en-IN")}</td>
          </tr>)}
        </tbody>
      </table>}
    </div>
  </Panel>;
}


// ===================== PROFILE PAGE =====================
const PROFILE_TEXT: Record<"hi" | "en", Record<string, string>> = {
  hi: {
    email: "ईमेल", role: "भूमिका", admin: "एडमिन", member: "सदस्य",
    name: "पूरा नाम", namePh: "आपका नाम", save: "सेव करें", saving: "सेव हो रहा है...",
    saved: "✅ प्रोफ़ाइल अपडेट हो गई।", emptyName: "नाम खाली नहीं हो सकता।",
    noPerm: "नाम सेव नहीं हुआ (अनुमति नहीं मिली)।", loading: "लोड हो रहा है...",
    activity: "इस महीने की मेरी गतिविधि", attendance: "उपस्थिति",
    presentTotal: "उपस्थित / कुल सत्र", quizzes: "दी गई परीक्षाएँ",
    avg: "औसत अंक", certs: "प्रमाणपत्र", myCerts: "मेरे प्रमाणपत्र",
    noCerts: "अभी कोई प्रमाणपत्र जारी नहीं हुआ है।", period: "अवधि",
    certNo: "प्रमाणपत्र क्रमांक", issued: "जारी", print: "प्रिंट / PDF सेव करें",
    history: "मेरी परीक्षाओं का इतिहास", noHistory: "अभी तक कोई परीक्षा नहीं दी है।",
    score: "अंक", logout: "लॉग आउट", locale: "hi-IN",
    weekly_quiz: "साप्ताहिक परीक्षा उपलब्धि",
    monthly_morning: "मासिक प्रातःकालीन स्वाध्याय उपस्थिति",
    monthly_evening: "मासिक सायंकालीन स्वाध्याय उपस्थिति",
  },
  en: {
    email: "Email", role: "Role", admin: "Administrator", member: "Member",
    name: "Full name", namePh: "Your name", save: "Save", saving: "Saving...",
    saved: "✅ Profile updated.", emptyName: "Name cannot be empty.",
    noPerm: "Name was not saved (permission denied).", loading: "Loading...",
    activity: "My activity this month", attendance: "Attendance",
    presentTotal: "Present / Total sessions", quizzes: "Quizzes taken",
    avg: "Average score", certs: "Certificates", myCerts: "My certificates",
    noCerts: "No certificate has been issued yet.", period: "Period",
    certNo: "Certificate No.", issued: "Issued", print: "Print / Save PDF",
    history: "My quiz history", noHistory: "You have not taken any quiz yet.",
    score: "Score", logout: "Log out", locale: "en-IN",
    weekly_quiz: "Weekly Quiz Achievement",
    monthly_morning: "Monthly Morning Swadhyay Attendance",
    monthly_evening: "Monthly Evening Swadhyay Attendance",
  },
};

export function ProfilePage({ lang, email, admin, onNameSaved }: {
  lang: "hi" | "en";
  email: string;
  admin: boolean;
  onNameSaved: (name: string) => void;
}) {
  const x = PROFILE_TEXT[lang];
  const [uid, U] = useState("");
  const [name, N] = useState("");
  const [msg, G] = useState("");
  const [err, E] = useState("");
  const [busy, B] = useState(false);
  const [stats, ST] = useState<any>(null);
  const [certs, CS] = useState<any[]>([]);
  const [history, H] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const { data: u } = await supabase.auth.getUser();
        const id = u.user?.id;
        if (!id) return;
        U(id);

        const pr = await supabase.from("profiles").select("full_name").eq("id", id).maybeSingle();
        if (pr.error) throw pr.error;
        N(pr.data?.full_name || "");

        if (admin) return;

        const held = await supabase.from("attendance_sessions").select("id")
          .eq("status", "held").gte("session_date", monthStartStr());
        if (held.error) throw held.error;
        const ids = (held.data || []).map((r: any) => r.id);

        let present = 0;
        if (ids.length) {
          const rec = await supabase.from("attendance_records").select("id")
            .eq("user_id", id).eq("status", "present").in("attendance_session_id", ids);
          if (rec.error) throw rec.error;
          present = (rec.data || []).length;
        }

        const hi = await supabase.rpc("get_my_jainvaani_quiz_history", { p_limit: 100 });
        if (hi.error) throw hi.error;
        const rows: any[] = hi.data || [];
        const sc = rows.reduce((a, r) => a + Number(r.score || 0), 0);
        const tp = rows.reduce((a, r) => a + Number(r.total_points || 0), 0);
        H(rows.slice(0, 10));

        const ce = await supabase.rpc("get_my_jainvaani_certificates");
        if (ce.error) throw ce.error;
        CS(ce.data || []);

        ST({
          held: ids.length,
          present,
          pct: ids.length ? Math.round((present * 100) / ids.length) : 0,
          quizzes: rows.length,
          avg: tp ? Math.round((sc * 100) / tp) : 0,
        });
      } catch (e: any) {
        E(errText(e));
      }
    })();
  }, [admin]);

  async function saveName(e: FormEvent) {
    e.preventDefault();
    E(""); G("");
    if (!name.trim()) { E(x.emptyName); return; }
    B(true);
    const r = await supabase.from("profiles").update({ full_name: name.trim() }).eq("id", uid).select("id");
    B(false);
    if (r.error) E(errText(r.error));
    else if (!r.data || r.data.length === 0) E(x.noPerm);
    else { G(x.saved); onNameSaved(name.trim()); }
  }

  const initial = (name || email || "M").charAt(0).toUpperCase();

  return <>
    <Panel>
      <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <div style={{ width: 64, height: 64, borderRadius: "50%", background: "#f4e8d6", color: "#a96522", display: "grid", placeItems: "center", fontSize: 28, fontWeight: 700 }}>{initial}</div>
        <div style={{ minWidth: 0 }}>
          <h2 style={{ margin: 0 }}>{name || email}</h2>
          <p className="jv-muted" style={{ margin: "4px 0 0", wordBreak: "break-all" }}>{x.email}: {email}</p>
          <p className="jv-muted" style={{ margin: "2px 0 0" }}>{x.role}: {admin ? x.admin : x.member}</p>
        </div>
      </div>

      <form className="jv-form" onSubmit={saveName}>
        <label>{x.name}
          <input value={name} onChange={e => N(e.target.value)} placeholder={x.namePh} />
        </label>
        <button className="jv-btn" disabled={busy || !uid}>{busy ? x.saving : x.save}</button>
      </form>
      {err && <div className="jv-error">{err}</div>}
      {msg && <p><b>{msg}</b></p>}
    </Panel>

    {!admin && <>
      <Panel>
        <h2>📊 {x.activity}</h2>
        {!stats && !err && <p className="jv-muted">{x.loading}</p>}
        {stats && <div className="jv-grid">
          <Stat label={x.attendance} value={`${stats.pct}%`} />
          <Stat label={x.presentTotal} value={`${stats.present}/${stats.held}`} />
          <Stat label={x.quizzes} value={stats.quizzes} />
          <Stat label={x.avg} value={`${stats.avg}%`} />
          <Stat label={x.certs} value={certs.length} />
        </div>}
      </Panel>

      <Panel>
        <h2>🏅 {x.myCerts}</h2>
        {certs.length === 0 && <p className="jv-muted">{x.noCerts}</p>}
        {certs.map(c => <article className="jv-row" key={c.certificate_id}>
          <h3>{x[c.certificate_type] || c.certificate_type}</h3>
          <p>{x.period}: {c.period_start} → {c.period_end}</p>
          <p>{x.certNo}: <b>{c.certificate_number}</b></p>
          <p className="jv-muted">{x.issued}: {new Date(c.issued_at).toLocaleDateString(x.locale)}</p>
          <button className="jv-btn" onClick={() => printCertificate(c)}>{x.print}</button>
        </article>)}
      </Panel>

      <Panel>
        <h2>🕘 {x.history}</h2>
        {history.length === 0 && <p className="jv-muted">{x.noHistory}</p>}
        {history.map(h => <article className="jv-row" key={h.attempt_id}>
          <h3>{h.quiz_title}</h3>
          <p>{x.score}: <b>{h.score}/{h.total_points}</b></p>
          <p className="jv-muted">{h.completed_at ? new Date(h.completed_at).toLocaleString(x.locale) : ""}</p>
        </article>)}
      </Panel>
    </>}

    <Panel>
      <button className="jv-btn alt" onClick={() => void supabase.auth.signOut()}>⎋ {x.logout}</button>
    </Panel>
  </>;
}