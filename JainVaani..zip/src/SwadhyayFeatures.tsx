import { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";

type SwadhyaySession = {
  id: string;
  session_key: "morning" | "evening";
  title: string;
  schedule_time: string;
  zoom_url: string | null;
  is_active: boolean;
};

const defaults = [
  { session_key: "morning" as const, title: "परमात्मप्रकाश", schedule_time: "08:15 AM" },
  { session_key: "evening" as const, title: "मोक्षमार्गप्रकाश", schedule_time: "08:15 PM" }
];

const styles = `
.swz-wrap{display:grid;gap:16px;margin:20px 0}
.swz-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.swz-card{border:1px solid #eadfc9;border-radius:16px;background:#fffdf8;padding:20px;min-width:0}
.swz-top{display:flex;justify-content:space-between;align-items:center;gap:10px}
.swz-icon{font-size:22px}.swz-pill{font-size:10px;letter-spacing:1px;color:#55734a;background:#edf5e9;padding:6px 9px;border-radius:20px}
.swz-time{font-size:13px;color:#9b571f;font-weight:700;margin-top:18px}
.swz-card h3{margin:7px 0;color:#50351e;font-size:20px}.swz-card p{color:#786b5b;font-size:13px;margin:0 0 14px}
.swz-btn{display:inline-block;border:0;border-radius:9px;padding:10px 14px;background:#a65e20;color:white;text-decoration:none;font-weight:600;cursor:pointer}
.swz-muted{color:#817666;font-size:13px}.swz-error{background:#f9e9e4;color:#8a3425;padding:10px 12px;border-radius:9px;font-size:13px}
.swz-success{background:#edf5e9;color:#426b35;padding:10px 12px;border-radius:9px;font-size:13px}
.swz-admin{margin:22px 0 28px;padding:22px;border:1px solid #eadfc9;border-radius:18px;background:#fffdf8}
.swz-admin h2{margin:0 0 6px;color:#50351e;font-size:22px}.swz-admin>p{margin:0 0 18px;color:#786b5b;font-size:14px}
.swz-form{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.swz-form label{display:flex;flex-direction:column;gap:6px;color:#5d4934;font-size:13px;font-weight:600}
.swz-form input{width:100%;box-sizing:border-box;border:1px solid #dfd3bf;border-radius:10px;padding:11px 12px;background:#fff;font:inherit;color:#33291f}
.swz-wide{grid-column:1/-1}.swz-actions{display:flex;gap:9px;flex-wrap:wrap}
.swz-primary,.swz-secondary{border:0;border-radius:9px;padding:10px 15px;cursor:pointer;font-weight:600}
.swz-primary{background:#a65e20;color:white}.swz-secondary{background:#eee6d9;color:#60462d}
.swz-admin-list{display:grid;gap:10px;margin-top:20px}
.swz-admin-row{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:14px;border:1px solid #eee4d5;border-radius:12px;background:#fff}
.swz-admin-row b{color:#4c3826}.swz-admin-row small{display:block;color:#766958;margin-top:4px}
.swz-check{display:flex;gap:7px;align-items:center;color:#766958;font-size:13px}
@media(max-width:650px){.swz-grid{grid-template-columns:1fr}.swz-form{grid-template-columns:1fr}.swz-wide{grid-column:auto}.swz-admin-row{align-items:flex-start;flex-direction:column}}
`;

export function SwadhyaySessions() {
  const [items, setItems] = useState<SwadhyaySession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    supabase.from("jainvaani_sessions")
      .select("id, session_key, title, schedule_time, zoom_url, is_active")
      .eq("is_active", true)
      .order("session_key", { ascending: true })
      .then(({ data, error: loadError }) => {
        if (!alive) return;
        if (loadError) setError(loadError.message);
        else setItems((data || []) as SwadhyaySession[]);
        setLoading(false);
      });
    return () => { alive = false; };
  }, []);

  return (
    <div className="swz-wrap">
      <style>{styles}</style>
      {loading ? <p className="swz-muted">Swadhyay sessions load ho rahe hain...</p> :
        error ? <div className="swz-error">{error}</div> :
        items.length === 0 ? <p className="swz-muted">Abhi koi active session available nahi hai.</p> :
        <div className="swz-grid">{items.map((item) => (
          <article className="swz-card" key={item.id}>
            <div className="swz-top"><span className="swz-icon">{item.session_key === "morning" ? "☀" : "☾"}</span><span className="swz-pill">SCHEDULED</span></div>
            <div className="swz-time">{item.schedule_time}</div>
            <h3>{item.title}</h3>
            <p>{item.session_key === "morning" ? "प्रातःकालीन स्वाध्याय" : "सायंकालीन स्वाध्याय"}</p>
            {item.zoom_url
              ? <a className="swz-btn" href={item.zoom_url} target="_blank" rel="noreferrer">Join class ↗</a>
              : <span className="swz-muted">एडमिन ने अभी Zoom link नहीं जोड़ा है।</span>}
          </article>
        ))}</div>}
    </div>
  );
}

export function SwadhyayManager() {
  const [items, setItems] = useState<SwadhyaySession[]>([]);
  const [drafts, setDrafts] = useState<Record<string, { title: string; schedule_time: string; zoom_url: string; is_active: boolean }>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function loadSessions() {
    setLoading(true);
    setError("");
    const { data, error: loadError } = await supabase.from("jainvaani_sessions")
      .select("id, session_key, title, schedule_time, zoom_url, is_active")
      .order("session_key", { ascending: true });
    if (loadError) {
      setError(loadError.message);
    } else {
      const rows = (data || []) as SwadhyaySession[];
      setItems(rows);
      const next: typeof drafts = {};
      rows.forEach((row) => {
        next[row.session_key] = {
          title: row.title,
          schedule_time: row.schedule_time,
          zoom_url: row.zoom_url || "",
          is_active: row.is_active
        };
      });
      setDrafts(next);
    }
    setLoading(false);
  }

  useEffect(() => { void loadSessions(); }, []);

  async function saveSession(key: "morning" | "evening") {
    const draft = drafts[key];
    if (!draft?.title.trim() || !draft.schedule_time.trim()) {
      setError("Session name aur timing dono zaroori hain.");
      return;
    }
    if (draft.zoom_url.trim()) {
      try {
        const url = new URL(draft.zoom_url.trim());
        if (url.protocol !== "https:" && url.protocol !== "http:") throw new Error();
      } catch {
        setError("Valid Zoom URL daalo (https://...).");
        return;
      }
    }
    setSaving(key);
    setError("");
    setNotice("");
    const payload = {
      title: draft.title.trim(),
      schedule_time: draft.schedule_time.trim(),
      zoom_url: draft.zoom_url.trim() || null,
      is_active: draft.is_active
    };
    const sessionExists = items.some((item) => item.session_key === key);
    const { error: saveError } = sessionExists
      ? await supabase.from("jainvaani_sessions").update(payload).eq("session_key", key)
      : await supabase.from("jainvaani_sessions").insert({ ...payload, session_key: key });
    setSaving(null);
    if (saveError) setError(saveError.message);
    else {
      setNotice(key === "morning" ? "Morning Swadhyay update ho gaya." : "Evening Swadhyay update ho gaya.");
      await loadSessions();
    }
  }

  return (
    <section className="swz-admin">
      <style>{styles}</style>
      <h2>◷ Swadhyay & Zoom Links</h2>
      <p>Morning aur evening session ka naam, timing aur Zoom link manage karo.</p>
      {error && <div className="swz-error">{error}</div>}
      {notice && <div className="swz-success">{notice}</div>}
      {loading ? <p className="swz-muted">Sessions load ho rahe hain...</p> :
        <div className="swz-grid">{defaults.map((fallback) => {
          const draft = drafts[fallback.session_key] || { ...fallback, zoom_url: "", is_active: true };
          const exists = items.some((item) => item.session_key === fallback.session_key);
          return (
            <div className="swz-card" key={fallback.session_key}>
              <h3>{fallback.session_key === "morning" ? "☀ Morning Swadhyay" : "☾ Evening Swadhyay"}</h3>
{!exists && <p className="swz-muted">Ye session abhi bana nahi hai. Details bharke "Create session" dabao.</p>}
              <div className="swz-form">
                <label>Granth / session name
                  <input value={draft.title} onChange={(e) => setDrafts((old) => ({ ...old, [fallback.session_key]: { ...draft, title: e.target.value } }))} />
                </label>
                <label>Timing
                  <input value={draft.schedule_time} onChange={(e) => setDrafts((old) => ({ ...old, [fallback.session_key]: { ...draft, schedule_time: e.target.value } }))} placeholder="08:15 AM" />
                </label>
                <label className="swz-wide">Zoom link
                  <input type="url" value={draft.zoom_url} onChange={(e) => setDrafts((old) => ({ ...old, [fallback.session_key]: { ...draft, zoom_url: e.target.value } }))} placeholder="https://zoom.us/j/..." />
                </label>
                <label className="swz-wide swz-check">
                  <input type="checkbox" checked={draft.is_active} onChange={(e) => setDrafts((old) => ({ ...old, [fallback.session_key]: { ...draft, is_active: e.target.checked } }))} />
                  Show this session to members
                </label>
                <div className="swz-wide swz-actions">
<button className="swz-primary" disabled={saving !== null} onClick={() => void saveSession(fallback.session_key)}>
  {saving === fallback.session_key ? "Saving..." : exists ? "Save changes" : "Create session"}
</button>
                </div>
              </div>
            </div>
          );
        })}</div>}
    </section>
  );
}
